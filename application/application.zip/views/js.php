    <!-- Modernizr -->
	<!--<script src="<?php echo base_url()?>public/js/modernizr.js"></script>-->
	
	<script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>

    <!--[if lt IE 9]-->
      <!--<script src="<?php echo base_url()?>public/js/html5shiv.min.js"></script>-->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js"></script>
      
      
      <!--<script src="<?php echo base_url()?>public/js/respond.min.js"></script>-->
      
      <script src="https://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.min.js"></script>
    <!--[endif]-->

<!--<script src="<?php echo base_url()?>public/js/jquery-2.2.4.min.js"></script>-->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>


<script src="<?php echo base_url()?>public/js/common_scripts_min.js"></script>
<script src="<?php echo base_url()?>public/js/functions.js"></script>
<!--<script src="--><?php //echo base_url()?><!--public/assets/validate.js"></script>-->
