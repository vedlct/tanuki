<!-- Footer ================================================== -->
	<footer>
        <div class="container">

            <div class="row">
               
                <div class="col-md-4 col-sm-3">
                    <div align="center" class="authorize">
                        <h3>Secure payments with</h3>
                        <p class="jetpay"><img src="<?php echo base_url()?>public/img/logo_lg.png" alt="" class="img-responsive"></p>
                    </div>

                </div>
               
                <div class="col-md-8">
                    <div id="social_footer">
                        <ul>
                            <li><a href="#0"><i class="icon-facebook"></i></a></li>
                            <li><a href="#0"><i class="icon-twitter"></i></a></li>
                            <li><a href="#0"><i class="icon-google"></i></a></li>
                            <li><a href="#0"><i class="icon-instagram"></i></a></li>
                            <li><a href="#0"><i class="icon-pinterest"></i></a></li>
                            <li><a href="#0"><i class="icon-vimeo"></i></a></li>
                            <li><a href="#0"><i class="icon-youtube-play"></i></a></li>
                        </ul>
                        <p>© <b>T A N U K I</b> - 2017</p>
                    </div>
                </div>
            </div><!-- End row -->
        </div><!-- End container -->
    </footer>
<!-- End Footer =============================================== -->