<!-- start footer -->
        <div class="page-footer">
            <div class="page-footer-inner"> 2017 &copy; Tech cloud ltd
                <a href="mailto:rtthememaker@gmail.com" target="_top"></a>
            </div>
            <div class="scroll-to-top">
                <i class="icon-arrow-up"></i>
            </div>
        </div>
        <!-- end footer -->
