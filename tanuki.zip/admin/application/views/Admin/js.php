


<!-- start js include path -->

<script src="<?php echo base_url()?>public/js/jquery.blockui.min.js" type="text/javascript"></script>
<script src="<?php echo base_url()?>public/js/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
<script src="<?php echo base_url()?>public/js/jquery-validation/js/additional-methods.min.js" type="text/javascript"></script>
<!-- bootstrap -->
<script src="<?php echo base_url()?>public/js/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script src="<?php echo base_url()?>public/js/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
<!--<script src="--><?php //echo base_url()?><!--public/js/bootstrap-wizard/jquery.bootstrap.wizard.min.js" type="text/javascript"></script>-->
<!--<script src="--><?php //echo base_url()?><!--public/js/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js" type="text/javascript" charset="UTF-8"></script>-->
<!--<script src="--><?php //echo base_url()?><!--public/js/bootstrap-datetimepicker/js/bootstrap-datetimepicker-init.js" type="text/javascript" charset="UTF-8"></script>-->
<!--<script src="--><?php //echo base_url()?><!--public/js/bootstrap-timepicker/js/bootstrap-timepicker.min.js" type="text/javascript" charset="UTF-8"></script>-->
<!--<script src="--><?php //echo base_url()?><!--public/js/bootstrap-timepicker/js/bootstrap-timepicker-init.js" type="text/javascript" charset="UTF-8"></script>-->
<!--<script src="--><?php //echo  base_url()?><!--public/js/bootstrap-datepicker/js/bootstrap-datepicker.min.js" type="text/javascript" charset="UTF-8"></script>-->
<!-- dropzone -->
<!--<script src="--><?php //echo base_url()?><!--public/js/dropzone/dropzone.js" type="text/javascript"></script>-->
<!--<script src="--><?php //echo base_url()?><!--public/js/dropzone/dropzone-call.js" type="text/javascript"></script>-->

<script src="<?php echo base_url()?>public/js/jquery.slimscroll.js"></script>
<script src="<?php echo base_url()?>public/js/app.js" type="text/javascript"></script>
<!--<script src="--><?php //echo base_url()?><!--public/js/form-wizard.js" type="text/javascript"></script>-->
<script src="<?php echo base_url()?>public/js/layout.js" type="text/javascript"></script>

<!-- end js include path -->


<!-- date picker  -->

<script src="<?php echo base_url()?>public/js/datepicker.js"></script>
<script src="<?php echo base_url()?>public/js/main.js"></script>

<!-- date picker  -->

