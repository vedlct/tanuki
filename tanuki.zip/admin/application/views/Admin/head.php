
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta name="description" content="Responsive Admin Template" />
    <meta name="author" content="RedstarHospital" />
    <title>Food Project</title>

    <!-- google font -->
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&amp;subset=all" rel="stylesheet" type="text/css" />
    
	<!-- icons -->
    <link href="<?php echo base_url()?>public/js/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url()?>public/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>



	<!--bootstrap -->
    <link href="<?php echo base_url()?>public/js/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url()?>public/js/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css" />
    


    <!-- Theme Styles -->
    <link href="<?php echo base_url()?>public/css/theme_style.css" rel="stylesheet" id="rt_style_components" type="text/css" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>public/css/modal.css " />

    <link href="<?php echo base_url()?>public/css/plugins.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url()?>public/css/style.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url()?>public/css/responsive.css" rel="stylesheet" type="text/css" />



	<!-- favicon -->
    <link rel="shortcut icon" href="<?php echo base_url()?>img/favicon.ico" />

    <!-- date picker      -->
    <link rel="stylesheet" href="<?php echo base_url()?>public/css/datepicker.css">

    <!-- date picker      -->

    <script src="<?php echo base_url()?>public/js/jquery.min.js" type="text/javascript"></script>


