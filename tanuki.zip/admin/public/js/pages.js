/**
 *  Document   : pages.js
 *  Author     : redstar
 *  Description: pages script
 *
 **/


$(window).resize(function(){
	 $( "body" ).css( "min-height",$( window ).height() );
});
$(document).ready(function(){
	 $( "body" ).css( "min-height",$( window ).height() );
});