<!-- start footer -->
        <div class="page-footer">
            <div class="page-footer-inner"> 2018 &copy; Tekno Visual
                <a href="mailto:rtthememaker@gmail.com" target="_top"></a>
            </div>
            <div class="scroll-to-top">
                <i class="icon-arrow-up"></i>
            </div>
        </div>
        <!-- end footer -->
